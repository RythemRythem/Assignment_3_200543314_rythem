// Function to retrieve form values and create a data object
function getFormValues(formId) {
    const form = document.getElementById(formId);
    const formData = {};
    
    // Loop through each form element
    for (const input of form.elements) {
        if (input.name) {
            // Check the type of input element
            if (input.type === 'checkbox') {
                // Handle checkboxes
                formData[input.name] = formData[input.name] || [];
                if (input.checked) {
                    formData[input.name].push(input.value);
                }
            } else if (input.type === 'radio' && input.checked) {
                // Handle radio buttons
                formData[input.name] = input.value;
            } else {
                // Handle other input types (text, select, etc.)
                formData[input.name] = input.value;
            }
        }
    }
    
    return formData;
}

// Smoothie class definition
class Smoothie {
    constructor(data) {
        this.flavor = data.flavor;
        this.extras = data.extras || [];
        this.size = data.size;
    }

    // Method to get a formatted description of the smoothie
    getDescription() {
        return `You ordered a ${this.size} ${this.flavor} smoothie with ${this.extras.join(', ')}.`;
    }
}

// Function to capture form values, create a Smoothie object, and display it
function orderSmoothie() {
    const formData = getFormValues('smoothieForm');
    const smoothie = new Smoothie(formData);
    displaySmoothie(smoothie);
}

// Function to display the smoothie description on the page
function displaySmoothie(smoothie) {
    const outputDiv = document.getElementById('smoothieOutput');
    outputDiv.innerHTML = `<p>${smoothie.getDescription()}</p>`;
}

